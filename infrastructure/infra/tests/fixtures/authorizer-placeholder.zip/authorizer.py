def handler(event, context): return {"isAuthorized": False}
